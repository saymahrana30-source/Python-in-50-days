# Python 50-Day Challenge

Learning Python from the ground up in 50 days — daily scripts, weekly mini-projects, and one capstone at the end. Built and documented publicly as a portfolio piece.

## Roadmap

| Days | Focus | Folder |
|------|-------|--------|
| 1–10 | Core fundamentals (variables, control flow, functions, strings/lists/dicts) | `day-01-10-fundamentals/` |
| 11–20 | OOP (classes, inheritance, file I/O, exceptions) | `day-11-20-oop/` |
| 21–30 | Data structures & problem solving (comprehensions, recursion, algorithms) | `day-21-30-data-structures/` |
| 31–40 | Libraries & real tools (`requests`, `pandas`, APIs, JSON, venvs) | `day-31-40-libraries-tools/` |
| 41–50 | Capstone project | `day-41-50-capstone/` |

## Progress Log

| Day | Topic | Status |
|-----|-------|--------|
| 01  | Variables, data types, I/O | ✅ |
| 02  | Control flow (if/else) | ⬜ |
| 03  | Loops | ⬜ |
| 04  | Functions | ⬜ |
| 05  | Strings | ⬜ |
| 06  | Lists | ⬜ |
| 07  | Dictionaries & Tuples | ⬜ |
| 08  | Sets & more string ops | ⬜ |
| 09  | Mini project 1 | ⬜ |
| 10  | Review + mini project 2 | ⬜ |

*(Days 11–50 get added to this table as the challenge progresses.)*

## How each day folder works

Each `dayXX/` folder contains:
- `notes.md` — concepts covered that day
- `main.py` (or task-specific scripts) — the actual code
- Sometimes a small `README.md` if the day involves a standalone mini-project

## About

Built by Sam — GTU student, freelance developer, streetwear founder ([BLAZE](#)). This challenge doubles as daily practice and portfolio material alongside other project work.
